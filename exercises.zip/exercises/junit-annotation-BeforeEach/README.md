
## Task
Create a TestClass with:

a test method which will print following output:
**"I am test method 1"**

a test method which will print following output:
**"I am test method 2"**

a method which will print following output:
**"I am setup method"**

Add appropriate annotation to the method which will print the below expected output:

## Output

* "I am setup method"
* "I am test method 1"

* "I am setup method"
* "I am test method 2"



