
## Task
Create a TestClass with:

a test method which will print following output:
**"I am test method 1"**

a test method which will print following output:
**"I am test method 2"**

a test method which will print following output:
**"I am test method 3"**

Add @TestMethodOrder & @Order to the test class and test methods which will print the below expected output:

## Output


* "I am test method 2"

* "I am test method 3"

* "I am test method 1"


