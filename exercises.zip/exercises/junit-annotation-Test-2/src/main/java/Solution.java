package main.java;

import org.junit.jupiter.api.Test;

public class Solution {

    @Test
    public void testMethod1(){
        System.out.println("I am test method 1");
    }

    @Test
    public void testMethod2(){
        System.out.println("I am test method 2");
    }
}
