package main.java;

import org.junit.jupiter.api.Test;

public class Solution {

    @Test
    public void myTest(){
        System.out.println("Welcome to Junit!");
    }
}
