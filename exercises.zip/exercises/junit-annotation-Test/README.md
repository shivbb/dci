
## Task
Create a TestClass which contains a test method.

Update the test method which will print the below expected output:

## Output

* "Welcome to Junit"

