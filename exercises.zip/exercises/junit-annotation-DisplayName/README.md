
## Task
Create a TestClass with:

a test method which will print following output:
**"I am test method 1"**

a test method which will print following output:
**"I am test method 2"**

Add appropriate annotations to the methods, so that
Junit "Test Result" window should display the test case names as below:
**"Method-1"**
**"Method-2"**

## Output

* "I am test method 1"
* "I am test method 2"