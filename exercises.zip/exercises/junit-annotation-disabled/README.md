
## Task
Create a TestClass with:

a test method which will print following output:
**"I am test method 1"**

a test method which will print following output:
**"I am test method 2"**

Add appropriate annotations to the test methods which will print the below expected output:

## Output

* "I am test method 2"

